from django.shortcuts import render
from newsapi import NewsApiClient

def index(request):
    newsapi = NewsApiClient(api_key='c22b341580d34260ba32319a7df69ae6')

    query = request.GET.get('query', '')  # Get search term
    if query:
        top = newsapi.get_everything(q=query, language='en', sort_by='publishedAt')
    else:
        top = newsapi.get_top_headlines(sources='techcrunch')

    articles = top.get('articles', [])
    news_list = []

    for article in articles:
        news_list.append({
            "title": article.get('title', 'No Title'),
            "description": article.get('description', 'No Description'),
            "image": article.get('urlToImage', 'https://via.placeholder.com/300'),  # Default image if missing
            "date": article.get('publishedAt', 'Unknown Date')[:10],  # Extract only YYYY-MM-DD
            "source": article.get('source', {}).get('name', 'Unknown Source'),
            "url": article.get('url', '#')
        })

    return render(request, 'index.html', {"news_list": news_list, "query": query})
